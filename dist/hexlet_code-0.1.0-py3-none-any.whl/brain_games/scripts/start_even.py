from brain_games.games_script import start_game
from brain_games.games.brain_even import start_even


if __name__ == '__main__':
    start_game(start_even)
