from brain_games.scripts.games_script import start_game
from brain_games.games.brain_prime import start_prime


if __name__ == '__main__':
    start_game(start_prime)
