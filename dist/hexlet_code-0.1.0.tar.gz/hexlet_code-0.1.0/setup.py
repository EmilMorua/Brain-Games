# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.start_calc:main',
                     'brain-even = brain_games.scripts.start_even:main',
                     'brain-games = brain_games.scripts.welcome_mass:main',
                     'brain-gcd = brain_games.scripts.start_gcd:main',
                     'brain-prime = brain_games.scripts.start_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.start_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/EmilMorua/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EmilMorua/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/f4f9ad083c37e0a3c11c/maintainability)](https://codeclimate.com/github/EmilMorua/python-project-49/maintainability)\n![brain-even](https://asciinema.org/a/qnd7WrClR0igYN8H8u4aTGhr6)\n![brain-calc](https://asciinema.org/a/01uhZLowixZAfuG3m1Ow0akjt)\n![brain-gcd](https://asciinema.org/a/A0QZ5G8zH3bPDxq01WbJUhAMA)\n![brain-progression](https://asciinema.org/a/LDqg6aMi3aT1xmbjsbA4Pu8rT)\n![brain-prime](https://asciinema.org/a/9QiSJVjzyZ75h5VdnlALau88A)\n',
    'author': 'Emil Murzin',
    'author_email': 'emil.morua@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10.6,<4.0.0',
}


setup(**setup_kwargs)
