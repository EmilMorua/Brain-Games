import prompt
import random
import sys
from brain_games.scripts.brain_games import main
from brain_games.cli import name


main()
print('Answer "yes" if the number is even, otherwise answer "no".')

random_num = random.randint(1,100)
count_correct_answ = 0
while (count_correct_answ < 3):
    print(f'Question: {random_num}')
    answer = prompt.string('Your answer: ')
    if random_num % 2 == 0:
        if answer == 'yes':
            print('Correct!')
            count_correct_answ += 1
        sys.exit(f"'{answer}' is wrong answer ;(. Correct answer was 'yes'.\nLet's try again, {name}!")
    elif random_num % 2 != 0:
        if answer == 'no':
            print('Correct!')
            count_correct_answ += 1
        sys.exit(f"'{answer}' is wrong answer ;(. Correct answer was 'no'.\nLet's try again, {name}!")

print(f"Congratulations, {name}!")
