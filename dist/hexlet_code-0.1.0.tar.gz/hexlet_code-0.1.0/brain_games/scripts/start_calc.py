from brain_games.scripts.games_script import start_game
from brain_games.games.brain_calc import start_calc


if __name__ == '__main__':
    start_game(start_calc())
