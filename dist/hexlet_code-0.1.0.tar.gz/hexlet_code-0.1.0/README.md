### Hexlet tests and linter status:
[![Actions Status](https://github.com/EmilMorua/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EmilMorua/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/f4f9ad083c37e0a3c11c/maintainability)](https://codeclimate.com/github/EmilMorua/python-project-49/maintainability)
![brain-even](https://asciinema.org/a/qnd7WrClR0igYN8H8u4aTGhr6)
![brain-calc](https://asciinema.org/a/01uhZLowixZAfuG3m1Ow0akjt)
![brain-gcd](https://asciinema.org/a/A0QZ5G8zH3bPDxq01WbJUhAMA)
![brain-progression](https://asciinema.org/a/LDqg6aMi3aT1xmbjsbA4Pu8rT)
![brain-prime](https://asciinema.org/a/9QiSJVjzyZ75h5VdnlALau88A)
