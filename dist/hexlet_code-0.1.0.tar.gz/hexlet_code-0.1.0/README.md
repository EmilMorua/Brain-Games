### Hexlet tests and linter status:
[![Actions Status](https://github.com/EmilMorua/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/EmilMorua/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/f4f9ad083c37e0a3c11c/maintainability)](https://codeclimate.com/github/EmilMorua/python-project-49/maintainability)
